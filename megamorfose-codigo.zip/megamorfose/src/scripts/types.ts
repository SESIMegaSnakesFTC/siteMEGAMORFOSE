// Modelo de conteúdo único e extensível. Todo conteúdo gerenciável (vídeos, cursos,
// oportunidades, histórias...) é um ContentItem com campos comuns + `fields` específicos
// do tipo, descritos no registro de tipos (src/scripts/contentTypes.ts). Assim, um novo tipo
// de conteúdo é adicionado sem mudar o banco nem as telas do painel administrativo.

export type AreaId = 'ia' | 'eletronica' | 'mecanica' | 'geral';
export type Level = 'iniciante' | 'intermediario' | 'avancado';
export type Status = 'draft' | 'published' | 'archived';

export type ContentType =
  | 'video'
  | 'tutorial'
  | 'course'
  | 'tool'
  | 'guide'
  | 'material'
  | 'practice'
  | 'opportunity'
  | 'program'
  | 'job'
  | 'competition'
  | 'scholarship'
  | 'university'
  | 'story'
  | 'event'
  | 'showcase'
  | 'school_guide'
  | 'resource'
  | 'glossary'
  | 'challenge'
  | 'path';

export type FieldValue = string | number | boolean | string[] | null | undefined;

export interface ContentItem {
  id: string;
  type: ContentType;
  title: string;
  summary: string;
  body?: string;
  cover?: string; // URL de imagem; vazio = capa ilustrada gerada
  area: AreaId;
  category?: string;
  tags: string[];
  level?: Level;
  duration?: string;
  url?: string; // link externo oficial
  videoUrl?: string; // YouTube/Vimeo
  status: Status;
  featured?: boolean;
  demo?: boolean; // "Conteúdo demonstrativo"
  fields: Record<string, FieldValue>;
  createdAt: string;
  updatedAt: string;
}

export type Role = 'student' | 'admin';

export interface Profile {
  id: string;
  name: string;
  email: string;
  role: Role;
  city?: string;
  ageRange?: 'menor13' | '13a17' | '18mais';
  guardianConsent?: boolean;
  interests: AreaId[];
  bio?: string;
  publicProfile: boolean;
  goals: Goal[];
  plannedProjects: PlannedProject[];
  createdAt: string;
}

export interface Goal {
  id: string;
  text: string;
  done: boolean;
}

export interface PlannedProject {
  id: string;
  title: string;
  area: AreaId;
  stage: 'ideia' | 'fazendo' | 'concluido';
}

export interface UserData {
  bookmarks: string[];
  completed: string[]; // ids de conteúdos concluídos
  challengesDone: string[];
  interests: string[]; // ids de publicações de colaboração com interesse
  groups: string[]; // grupos/comunidades que o estudante segue
}

export type PostKind = 'projeto' | 'colaboracao' | 'evento' | 'novidade';
export interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string; // apenas primeiro nome
  kind: PostKind;
  area: AreaId;
  title: string;
  text: string;
  status: 'pending' | 'approved' | 'rejected';
  reports: number;
  createdAt: string;
}

export interface Group {
  id: string;
  name: string;
  area: AreaId;
  kind: 'estudo' | 'clube' | 'comunidade';
  description: string;
  demo?: boolean;
}
