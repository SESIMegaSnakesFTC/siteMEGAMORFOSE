import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { SEED, SEED_POSTS } from '../dados/seed';
import type { CommunityPost, ContentItem, Profile, UserData } from './types';

// Camada de dados. Duas implementações com a mesma interface:
//  • LocalBackend   — modo demonstração, tudo no localStorage do navegador.
//  • SupabaseBackend — produção (Postgres + Auth + RLS), ativado por VITE_SUPABASE_URL/ANON_KEY.
// As telas só conhecem a interface Backend, então trocar de modo não muda nenhuma página.

export type UserFlag = 'bookmarks' | 'completed' | 'challengesDone' | 'interests' | 'groups';

export interface SignUpInput {
  name: string;
  email: string;
  password: string;
  ageRange: Profile['ageRange'];
  guardianConsent: boolean;
  city?: string;
}

export interface Backend {
  mode: 'demo' | 'supabase';
  listContent(includeUnpublished: boolean): Promise<ContentItem[]>;
  saveContent(item: ContentItem): Promise<ContentItem>;
  deleteContent(id: string): Promise<void>;
  resetDemo?(): Promise<void>;
  uploadImage(file: File): Promise<string>;

  currentUser(): Promise<Profile | null>;
  signUp(input: SignUpInput): Promise<Profile>;
  signIn(email: string, password: string): Promise<Profile>;
  signOut(): Promise<void>;
  updateProfile(p: Profile): Promise<Profile>;
  deleteAccount(uid: string): Promise<void>;

  getUserData(uid: string): Promise<UserData>;
  setFlag(uid: string, flag: UserFlag, id: string, on: boolean): Promise<void>;

  listPosts(includeAll: boolean): Promise<CommunityPost[]>;
  createPost(p: Omit<CommunityPost, 'id' | 'status' | 'reports' | 'createdAt'>): Promise<CommunityPost>;
  moderatePost(id: string, status: CommunityPost['status']): Promise<void>;
  reportPost(id: string): Promise<void>;
}

export const EMPTY_USERDATA: UserData = { bookmarks: [], completed: [], challengesDone: [], interests: [], groups: [] };

export const newId = () =>
  (globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`);

// ─────────────────────────────── Local (demo) ───────────────────────────────

const K = {
  content: 'mm:content:v2',
  users: 'mm:users:v1',
  session: 'mm:session:v1',
  posts: 'mm:posts:v2',
  data: (uid: string) => `mm:userdata:v1:${uid}`,
};

const read = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
};
const write = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* armazenamento indisponível (aba anônima, cota): segue só em memória */
  }
};

async function hash(text: string) {
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch {
    let h = 0;
    for (const c of text) h = (Math.imul(31, h) + c.charCodeAt(0)) | 0;
    return `weak-${h}`;
  }
}

interface LocalUser extends Profile {
  salt: string;
  pass: string;
}

// Conta de administrador APENAS para o modo demonstração local.
// Em produção (Supabase), o papel de admin é definido no banco (ver supabase/schema.sql).
export const DEMO_ADMIN = { email: 'admin@megamorfose.demo', password: 'megamorfose' };

const strip = ({ salt: _s, pass: _p, ...profile }: LocalUser): Profile => profile;
const tick = () => new Promise((r) => setTimeout(r, 120));

class LocalBackend implements Backend {
  mode = 'demo' as const;

  private content(): ContentItem[] {
    return read<ContentItem[] | null>(K.content, null) ?? SEED;
  }
  private async users(): Promise<LocalUser[]> {
    const list = read<LocalUser[]>(K.users, []);
    if (!list.some((u) => u.email === DEMO_ADMIN.email)) {
      const salt = newId();
      list.push({
        id: 'demo-admin', name: 'Equipe MegaMorfose', email: DEMO_ADMIN.email, role: 'admin', interests: [],
        publicProfile: false, goals: [], plannedProjects: [], createdAt: new Date().toISOString(), ageRange: '18mais',
        salt, pass: await hash(salt + DEMO_ADMIN.password),
      });
      write(K.users, list);
    }
    return list;
  }

  async listContent(all: boolean) {
    await tick();
    const items = this.content();
    return all ? items : items.filter((i) => i.status === 'published');
  }
  async saveContent(item: ContentItem) {
    const items = this.content();
    const next = { ...item, updatedAt: new Date().toISOString() };
    const idx = items.findIndex((i) => i.id === item.id);
    if (idx >= 0) items[idx] = next;
    else items.unshift(next);
    write(K.content, items);
    return next;
  }
  async deleteContent(id: string) {
    write(K.content, this.content().filter((i) => i.id !== id));
  }
  async uploadImage(file: File) {
    // Demo: a imagem vira data URL salva junto do conteúdo (limite para não estourar o localStorage).
    if (file.size > 400_000) throw new Error('No modo demonstração, use imagens de até 400 KB ou cole um link.');
    return new Promise<string>((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result));
      r.onerror = () => reject(new Error('Não foi possível ler a imagem.'));
      r.readAsDataURL(file);
    });
  }
  async resetDemo() {
    localStorage.removeItem(K.content);
    localStorage.removeItem(K.posts);
  }

  async currentUser() {
    const id = read<string | null>(K.session, null);
    if (!id) return null;
    const u = (await this.users()).find((x) => x.id === id);
    return u ? strip(u) : null;
  }
  async signUp(input: SignUpInput) {
    const users = await this.users();
    const email = input.email.trim().toLowerCase();
    if (users.some((u) => u.email === email)) throw new Error('Já existe uma conta com este e-mail.');
    const salt = newId();
    const user: LocalUser = {
      id: newId(), name: input.name.trim(), email, role: 'student', city: input.city?.trim(), ageRange: input.ageRange,
      guardianConsent: input.guardianConsent, interests: [], publicProfile: false, goals: [], plannedProjects: [],
      createdAt: new Date().toISOString(), salt, pass: await hash(salt + input.password),
    };
    write(K.users, [...users, user]);
    write(K.session, user.id);
    return strip(user);
  }
  async signIn(email: string, password: string) {
    await tick();
    const u = (await this.users()).find((x) => x.email === email.trim().toLowerCase());
    if (!u || u.pass !== (await hash(u.salt + password))) throw new Error('E-mail ou senha incorretos.');
    write(K.session, u.id);
    return strip(u);
  }
  async signOut() {
    localStorage.removeItem(K.session);
  }
  async updateProfile(p: Profile) {
    const users = await this.users();
    const idx = users.findIndex((u) => u.id === p.id);
    if (idx < 0) throw new Error('Usuário não encontrado.');
    users[idx] = { ...users[idx], ...p, role: users[idx].role, email: users[idx].email };
    write(K.users, users);
    return strip(users[idx]);
  }
  async deleteAccount(uid: string) {
    write(K.users, (await this.users()).filter((u) => u.id !== uid));
    localStorage.removeItem(K.data(uid));
    localStorage.removeItem(K.session);
  }

  async getUserData(uid: string) {
    return { ...EMPTY_USERDATA, ...read<Partial<UserData>>(K.data(uid), {}) };
  }
  async setFlag(uid: string, flag: UserFlag, id: string, on: boolean) {
    const d = await this.getUserData(uid);
    const set = new Set(d[flag]);
    if (on) set.add(id);
    else set.delete(id);
    write(K.data(uid), { ...d, [flag]: [...set] });
  }

  private posts(): CommunityPost[] {
    return read<CommunityPost[] | null>(K.posts, null) ?? (SEED_POSTS as unknown as CommunityPost[]);
  }
  async listPosts(all: boolean) {
    const me = read<string | null>(K.session, null);
    return this.posts().filter((p) => all || p.status === 'approved' || p.authorId === me);
  }
  async createPost(p: Omit<CommunityPost, 'id' | 'status' | 'reports' | 'createdAt'>) {
    const post: CommunityPost = { ...p, id: newId(), status: 'pending', reports: 0, createdAt: new Date().toISOString() };
    write(K.posts, [post, ...this.posts()]);
    return post;
  }
  async moderatePost(id: string, status: CommunityPost['status']) {
    write(K.posts, this.posts().map((p) => (p.id === id ? { ...p, status } : p)));
  }
  async reportPost(id: string) {
    // 3 denúncias retiram a publicação do ar até nova moderação.
    write(K.posts, this.posts().map((p) => (p.id === id ? { ...p, reports: p.reports + 1, status: p.reports + 1 >= 3 ? 'pending' : p.status } : p)));
  }
}

// ─────────────────────────────── Supabase ───────────────────────────────

type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any

const toItem = (r: Row): ContentItem => ({
  id: r.id, type: r.type, title: r.title, summary: r.summary ?? '', body: r.body ?? undefined, cover: r.cover ?? undefined,
  area: r.area, category: r.category ?? undefined, tags: r.tags ?? [], level: r.level ?? undefined, duration: r.duration ?? undefined,
  url: r.url ?? undefined, videoUrl: r.video_url ?? undefined, status: r.status, featured: r.featured, demo: r.demo,
  fields: r.fields ?? {}, createdAt: r.created_at, updatedAt: r.updated_at,
});
const fromItem = (i: ContentItem): Row => ({
  id: i.id, type: i.type, title: i.title, summary: i.summary, body: i.body ?? null, cover: i.cover ?? null, area: i.area,
  category: i.category ?? null, tags: i.tags, level: i.level ?? null, duration: i.duration ?? null, url: i.url ?? null,
  video_url: i.videoUrl ?? null, status: i.status, featured: !!i.featured, demo: !!i.demo, fields: i.fields,
});
const toProfile = (r: Row, email: string): Profile => ({
  id: r.id, name: r.name, email, role: r.role, city: r.city ?? undefined, ageRange: r.age_range ?? undefined,
  guardianConsent: r.guardian_consent, interests: r.interests ?? [], bio: r.bio ?? undefined, publicProfile: r.public_profile,
  goals: r.goals ?? [], plannedProjects: r.planned_projects ?? [], createdAt: r.created_at,
});

const FLAG_TABLE: Record<UserFlag, { table: string; col: string; extra?: Row }> = {
  bookmarks: { table: 'bookmarks', col: 'content_id' },
  completed: { table: 'progress', col: 'content_id', extra: { kind: 'content' } },
  challengesDone: { table: 'progress', col: 'content_id', extra: { kind: 'challenge' } },
  interests: { table: 'collab_interests', col: 'post_id' },
  groups: { table: 'group_members', col: 'group_id' },
};

class SupabaseBackend implements Backend {
  mode = 'supabase' as const;
  constructor(private sb: SupabaseClient) {}

  private ok<T>(res: { data: T; error: { message: string } | null }) {
    if (res.error) throw new Error(res.error.message);
    return res.data;
  }

  async listContent(all: boolean) {
    let q = this.sb.from('content_items').select('*').order('created_at', { ascending: false });
    if (!all) q = q.eq('status', 'published');
    return (this.ok(await q) as Row[]).map(toItem);
  }
  async saveContent(item: ContentItem) {
    return toItem(this.ok(await this.sb.from('content_items').upsert(fromItem(item)).select().single()) as Row);
  }
  async deleteContent(id: string) {
    this.ok(await this.sb.from('content_items').delete().eq('id', id));
  }

  async uploadImage(file: File) {
    const path = `${Date.now()}-${file.name.replace(/[^\w.-]/g, '_')}`;
    this.ok(await this.sb.storage.from('media').upload(path, file, { upsert: false }));
    return this.sb.storage.from('media').getPublicUrl(path).data.publicUrl;
  }

  async currentUser() {
    const { data } = await this.sb.auth.getUser();
    if (!data.user) return null;
    const row = this.ok(await this.sb.from('profiles').select('*').eq('id', data.user.id).maybeSingle()) as Row | null;
    return row ? toProfile(row, data.user.email ?? '') : null;
  }
  async signUp(input: SignUpInput) {
    const { data, error } = await this.sb.auth.signUp({
      email: input.email.trim(), password: input.password,
      options: { data: { name: input.name.trim(), age_range: input.ageRange, guardian_consent: input.guardianConsent, city: input.city ?? null } },
    });
    if (error) throw new Error(error.message);
    if (!data.session) throw new Error('Conta criada! Confirme seu e-mail para entrar.');
    const p = await this.currentUser();
    if (!p) throw new Error('Perfil não encontrado. Verifique o gatilho handle_new_user no banco.');
    return p;
  }
  async signIn(email: string, password: string) {
    const { error } = await this.sb.auth.signInWithPassword({ email: email.trim(), password });
    if (error) throw new Error('E-mail ou senha incorretos.');
    const p = await this.currentUser();
    if (!p) throw new Error('Perfil não encontrado.');
    return p;
  }
  async signOut() {
    await this.sb.auth.signOut();
  }
  async updateProfile(p: Profile) {
    // role não é enviado: só pode ser alterado no banco por um administrador.
    const row = this.ok(await this.sb.from('profiles').update({
      name: p.name, city: p.city ?? null, interests: p.interests, bio: p.bio ?? null, public_profile: p.publicProfile,
      goals: p.goals, planned_projects: p.plannedProjects,
    }).eq('id', p.id).select().single()) as Row;
    return toProfile(row, p.email);
  }
  async deleteAccount() {
    // Remoção definitiva exige função no servidor (service_role). Ver supabase/schema.sql → delete_my_account.
    this.ok(await this.sb.rpc('delete_my_account'));
    await this.sb.auth.signOut();
  }

  async getUserData(uid: string): Promise<UserData> {
    const [bm, pr, ci, gm] = await Promise.all([
      this.sb.from('bookmarks').select('content_id').eq('user_id', uid),
      this.sb.from('progress').select('content_id, kind').eq('user_id', uid),
      this.sb.from('collab_interests').select('post_id').eq('user_id', uid),
      this.sb.from('group_members').select('group_id').eq('user_id', uid),
    ]);
    const progress = (this.ok(pr) as Row[]) ?? [];
    return {
      bookmarks: (this.ok(bm) as Row[]).map((r) => r.content_id),
      completed: progress.filter((r) => r.kind === 'content').map((r) => r.content_id),
      challengesDone: progress.filter((r) => r.kind === 'challenge').map((r) => r.content_id),
      interests: (this.ok(ci) as Row[]).map((r) => r.post_id),
      groups: (this.ok(gm) as Row[]).map((r) => r.group_id),
    };
  }
  async setFlag(uid: string, flag: UserFlag, id: string, on: boolean) {
    const t = FLAG_TABLE[flag];
    if (on) this.ok(await this.sb.from(t.table).upsert({ user_id: uid, [t.col]: id, ...t.extra }));
    else {
      let q = this.sb.from(t.table).delete().eq('user_id', uid).eq(t.col, id);
      if (t.extra?.kind) q = q.eq('kind', t.extra.kind);
      this.ok(await q);
    }
  }

  async listPosts() {
    // As políticas RLS já limitam: aprovadas para todos, próprias para o autor, todas para admin.
    const rows = this.ok(await this.sb.from('community_posts').select('*').order('created_at', { ascending: false })) as Row[];
    return rows.map((r) => ({
      id: r.id, authorId: r.author_id, authorName: r.author_name, kind: r.kind, area: r.area, title: r.title, text: r.text,
      status: r.status, reports: r.reports, createdAt: r.created_at,
    }));
  }
  async createPost(p: Omit<CommunityPost, 'id' | 'status' | 'reports' | 'createdAt'>) {
    const r = this.ok(await this.sb.from('community_posts').insert({
      author_id: p.authorId, author_name: p.authorName, kind: p.kind, area: p.area, title: p.title, text: p.text,
    }).select().single()) as Row;
    return { ...p, id: r.id, status: r.status, reports: 0, createdAt: r.created_at };
  }
  async moderatePost(id: string, status: CommunityPost['status']) {
    this.ok(await this.sb.from('community_posts').update({ status }).eq('id', id));
  }
  async reportPost(id: string) {
    this.ok(await this.sb.rpc('report_post', { post_id: id }));
  }
}

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const backend: Backend = url && key ? new SupabaseBackend(createClient(url, key)) : new LocalBackend();
