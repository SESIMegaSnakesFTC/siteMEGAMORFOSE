import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import { AreaTriptych } from '../componentes/cards';
import { btn, PageHero, SectionHeader, useSeo } from '../componentes/ui';
import { AREAS } from '../scripts/areas';
import { useStore } from '../scripts/store';

export default function Explore() {
  useSeo('Explorar STEM', 'Conheça as três áreas dos workshops MegaMorfose: AI & Visão Computacional, Eletrônica e Mecânica.');
  const { items } = useStore();
  return (
    <>
      <PageHero eyebrow="Explorar STEM" title="Três áreas, um robô, infinitas possibilidades" text="Os workshops do MegaMorfose apresentam três áreas que, juntas, fazem um robô funcionar. Escolha uma para começar, ou explore todas.">
        <Link to="/por-onde-comecar" className={btn('primary')}><Sparkles className="h-4 w-4" /> Descobrir minha área</Link>
      </PageHero>
      <section className="section">
        <div className="container-x">
          <AreaTriptych />
        </div>
      </section>
      <section className="section bg-white">
        <div className="container-x">
          <SectionHeader eyebrow="Como tudo se conecta" title="Dentro de um robô de competição" text="Na FIRST Tech Challenge, cada robô precisa das três áreas trabalhando juntas." />
          <div className="grid gap-4 md:grid-cols-3">
            {AREAS.map((a, idx) => (
              <div key={a.id} className="card relative p-6">
                <span className={`grid h-10 w-10 place-items-center rounded-full font-display font-bold text-white ${a.solid}`}>{idx + 1}</span>
                <h3 className="mt-4 font-display text-xl font-bold">{['Os olhos e o cérebro', 'O sistema nervoso', 'O corpo e os músculos'][idx]}</h3>
                <p className="mt-2 text-ink-soft">
                  {[
                    'A visão computacional encontra objetos e alvos na arena; a IA ajuda o robô a decidir o que fazer.',
                    'Sensores, fios, baterias e controladores levam energia e informação para todas as partes do robô.',
                    'Chassi, engrenagens, braços e garras transformam a energia dos motores em movimento preciso.',
                  ][idx]}
                </p>
                <p className="mt-4 text-sm font-semibold text-ink-muted">{items.filter((i) => i.area === a.id).length} conteúdos disponíveis</p>
                <Link to={`/explorar/${a.slug}`} className={`mt-3 inline-flex items-center gap-1 text-sm font-bold ${a.text}`}>Explorar {a.short} <ArrowRight className="h-4 w-4" /></Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
